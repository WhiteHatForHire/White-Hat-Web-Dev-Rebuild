<?php
/**
 * The template for displaying all single posts.
 *
 * @package understrap
 */

get_header();
$container   = get_theme_mod( 'understrap_container_type' );
?>

<div class="wrapper" id="single-wrapper">

	<div class="<?php echo esc_attr( $container ); ?>" id="content" tabindex="-1">

		<div class="row">

			<!-- Do the left sidebar check -->
			<?php get_template_part( 'global-templates/left-sidebar-check' ); ?>

			<main class="site-main" id="main">

				<?php the_content(); ?>

			</main><!-- #main -->

		</div><!-- #primary -->

		<!-- Do the right sidebar check -->
		<?php get_template_part( 'global-templates/right-sidebar-check' ); ?>

	</div><!-- .row -->

</div><!-- Container end -->
<?php
if( have_rows('post_section') ):
$count=1;
    while ( have_rows('post_section') ) : the_row();
?>
<section id="section<?php echo $count; ?>" class="section parallax <?php the_sub_field('extra_class');?>" style="background-image: url(<?php the_sub_field('section_bg');?>); padding: <?php the_sub_field('section_padding');?> 0px; margin-bottom: <?php the_sub_field('margin_bottom');?>; min-height: <?php the_sub_field('section_height');?>;">
<div class="container-fluid">
<div class="row">

	<?php if (get_sub_field('full_content')!=''){ ?>
	<div class="col-md-8 offset-md-2">
		<?php the_sub_field('full_content'); ?>
	</div>
	<?php
	}else{
	?>
	<div class="col-md-6 image-container-root">
		<?php if (get_sub_field('section_left_content')!=''){ ?>
		<div class="white-bg shadow"><div class="imgae-container-text"><?php the_sub_field('section_left_content');?></div></div>
		<?php
		}else{
		?>
		<?php if (get_sub_field('left_image')!=''){ ?><img src="<?php the_sub_field('left_image');?>" alt="bg-image" class="img-fluid bg-image-culture"><?php } ?>
		<?php } ?>
		<div class="image-container ">
			<?php if (get_sub_field('section_floating_image')!=''){ ?><img src="<?php the_sub_field('section_floating_image');?>" alt="floting image" class="floating-image-culture shadow-low-opacity"><?php } ?>
		</div>
	</div>
	<div class="col-md-6 text-container">
		<div class="imgae-container-text">
			<?php the_sub_field('section_right_content'); ?>
		</div>
	</div>
	<?php } ?>
<?php if (get_sub_field('section_below_testimonial')!=''){ ?>
<div class="testi-section shadow" style="background-color: <?php the_sub_field('testimonial_background_color');?>">
<?php the_sub_field('section_below_testimonial');?>
</div>
<?php } ?>
</div>
</div>
</section>
<?php
$count++;
    endwhile;
endif;
?>
<div class="container">
<div class="row">
			<?php
			$args = array(
				'post_type' => 'case',
				'posts_per_page' => 4,
				'orderby' => 'menu_order',
                 'order' => 'DESC'
			);
			$query = new WP_Query( $args );
			?>
			<?php
			while ($query->have_posts() ): $query->the_post(); 
			$image = wp_get_attachment_url( get_post_thumbnail_id($post->ID)); ?>
			<div class="col-md-6">
			
			<div class="post-div">
			<a href="<?php the_permalink(); ?>">
			<div class="featured-img" style="background-image: url(<?php echo $image; ?>);">
			</div>
			<div class="post-content">
			<div class="case-extract-small-bg">
			<div class="case-extract-small-bg-inner" style="background-color: <?php the_field('bg_overlay_color'); ?>">
			</div>
			</div>
			<div class="case-extract-small-text">
			<span><?php the_field('author_name'); ?></span>
			<h3><?php the_title(); ?></h3>
			<h4><?php the_field('banner_sub_heading'); ?></h4>
			</div>
			</div>
			</a>
			</div>
			
			</div>
			<?php endwhile; // end of the loop. ?>
</div>
</div>
</div><!-- Wrapper end -->

<?php get_footer(); ?>
