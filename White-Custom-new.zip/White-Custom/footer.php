<!-- <div class="newsletter"> -->
<?php //echo do_shortcode('[email-subscribers namefield="YES" desc="" group="Public"]');?>
<!-- </div> -->
<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package understrap
 */

$the_theme = wp_get_theme();
$container = get_theme_mod( 'understrap_container_type' );
$footer_all = get_field('footer_section_content');
$footer_main = get_field('footer_content', 'options');
if($footer_all!=''){?>
<section class="footer_page">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <?php echo $footer_all;?>
            </div>
        </div>
    </div>
</section>
<?php } get_sidebar( 'footerfull' ); 
if($footer_main!=''){?>
<section class="footer_main">
    <div class="container">
                <?php echo $footer_main;?>
    </div>
</section>
<?php }?>
<div class="wrapper" id="wrapper-footer">

	<div class="<?php echo esc_attr( $container ); ?>">

		<div class="row">

			<div class="col-md-12">

				<footer class="site-footer" id="colophon">

					<div class="site-info">
						<p>Copyright © <?php echo date("Y");?> <?php echo $site_name = get_bloginfo( 'name' );  ?>. All Rights Reserved <!-- <span class="sep" style="display: none;">|</span> Custom Web Design By <a href="https://adrishya.co/" target="_blank" title="Adrishya IT">Adrishya IT</a> --> </p>
					</div><!-- .site-info -->

				</footer><!-- #colophon -->

			</div><!--col end -->

		</div><!-- row end -->

	</div><!-- container end -->

</div><!-- wrapper end -->

</div><!-- #page we need this extra closing tag here -->

<?php wp_footer(); ?>
<script src="<?php echo get_template_directory_uri(); ?>/js/withinviewport.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.withinviewport.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/parallax/jquery.stellar.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/parallax/jquery.scrollme.js"></script>
<script>
        jQuery(document).ready(function ($) {
        if (jQuery(window).width()>1025) {
            //initialise Stellar.js
            $(window).stellar({
            responsive: true,
            horizontalScrolling: false,
            verticalOffset: 0,
            horizontalOffset: 0
            });
        }
        })
        jQuery(document).ready(function(){
        new WOW().init();});
        jQuery(window).scroll(function() {    
            var scroll = jQuery(window).scrollTop();
            if (scroll >= 400) {
                jQuery(".navbar-trans").addClass("darkHeader");
            }else{
                jQuery('.navbar-trans').removeClass('darkHeader');
            }
        });
        (function($){
            $(function(){
                var current = location.pathname;
                $('.tab_category a').each(function(){
                    var $this = $(this);
                    if($this.attr('href').indexOf(current) !== -1){
                        $this.addClass('active');
                    }
                })
            })
        })(jQuery);
        // jQuery(window).scroll(function(){
        //     var offset=jQuery(".reached").offset().top+jQuery(".reached").height()/2;
        //     if(jQuery(window).scrollTop()>=offset){
        //         jQuery('.count').each(function(){
        //             if(!jQuery(this).hasClass('reachedtop')){
        //                 jQuery(this).prop('Counter',0).animate({
        //                     Counter:jQuery(this).text()},
        //                     {duration:2000,easing:'swing',step:function(now){
        //                         jQuery(this).text(Math.ceil(now));
        //                         jQuery(this).addClass('reachedtop');
        //                         jQuery(".progress").css({'overflow':'visible','position':'relative'});
        //                         jQuery(".progress .progress-bar").css({'-webkit-animation':'animate-positive 4s','animation':'animate-positive 4s'});
        //                         jQuery(".progress .progress-value").css({'position':'absolute'});}});
        //             }});
        //     }
        // });
        //if(jQuery(window).width()<767){jQuery(".top-header").appendTo(".navbar");}
</script>
<?php the_field('footer_script', 'options');?>
<script>
	jQuery('.post-listing').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    dots:false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:3
        }
    }
    })
    jQuery('.team_listing').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    dots:false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:4
        }
    }
    })
    jQuery('.client_listing').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    dots:true,
    autoplay:true,
    autoplayTimeout:1000,
    autoplayHoverPause:false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:5
        }
    }
    })
	jQuery('ul.navbar-nav li.dropdown').hover(function() {
        jQuery(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
    }, function() {
    jQuery(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
    });
    jQuery(document).ready(function(){
      // Add smooth scrolling to all links
      jQuery("a").on('click', function(event) {

        // Make sure this.hash has a value before overriding default behavior
        if (this.hash !== "") {
          // Prevent default anchor click behavior
          event.preventDefault();

          // Store hash
          var hash = this.hash;

          // Using jQuery's animate() method to add smooth page scroll
          // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
          jQuery('html, body').animate({
            scrollTop: jQuery(hash).offset().top
          }, 800, function(){
       
            // Add hash (#) to URL when done scrolling (default click behavior)
            window.location.hash = hash;
          });
        } // End if
      });
    });
</script>
<?php if(get_field('smooth_scroll', 'options')!=''){?>
<script>
    var $ = jQuery;
    $(function(){
    
    var $window = $(window);        //Window object
    
    var scrollTime = 1.2;           //Scroll time
    var scrollDistance = 170;       //Distance. Use smaller value for shorter scroll and greater value for longer scroll
        
    $window.on("mousewheel DOMMouseScroll", function(event){
        
        event.preventDefault(); 
                                        
        var delta = event.originalEvent.wheelDelta/120 || -event.originalEvent.detail/3;
        var scrollTop = $window.scrollTop();
        var finalScroll = scrollTop - parseInt(delta*scrollDistance);
            
        TweenMax.to($window, scrollTime, {
            scrollTo : { y: finalScroll, autoKill:true },
                ease: Power1.easeOut,   //For more easing functions see https://api.greensock.com/js/com/greensock/easing/package-detail.html
                autoKill: true,
                overwrite: 5                            
            });
                    
    });
    
});
</script>
<?php }?>
</body>

</html>

