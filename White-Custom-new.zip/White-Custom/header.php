<?php
$container = get_theme_mod( 'understrap_container_type' );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-title" content="<?php bloginfo( 'name' ); ?> - <?php bloginfo( 'description' ); ?>">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php wp_head(); ?>
	<link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>">
	<?php if(get_field('smooth_scroll', 'options')!=''){?>
	<script src="<?php echo get_template_directory_uri().'/js/smooth/TweenMax.min.js'; ?>"></script>
	<script src="<?php echo get_template_directory_uri().'/js/smooth/ScrollToPlugin.min.js'; ?>"></script>
	<?php }?>
	<link href='https://cdn.jsdelivr.net/npm/animate.css@3.5.2/animate.min.css' rel='stylesheet' type='text/css'>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js" ></script>
	<?php the_field('header_script', 'options');?>
</head>

<body <?php body_class(); ?>>

<div class="hfeed site" id="page">

	<!-- ******************* The Navbar Area ******************* -->
	<div class="wrapper-fluid wrapper-navbar" id="wrapper-navbar">

		<a class="skip-link screen-reader-text sr-only" href="#content"><?php esc_html_e( 'Skip to content',
		'understrap' ); ?></a>
		<?php if(get_field('header_top_bar', 'options')!=''){
			  $top_background_color = get_field('top_background_color', 'options');
			  $top_header_color = get_field('top_header_color', 'options'); ?>
		<div class="top-header" style="background-color: <?php echo $top_background_color;?>;color: <?php echo $top_header_color;?>">
		<div class="container">
			<div class="row">
						<div class="col-md-6 align-self-center">
							<div class="navbar-left">
								<div class="contact">
								<?php $phone=get_field('phone', 'options');
									  $email=get_field('email', 'options');
									   if($phone || $email!=''){echo 'Have any questions? ';}?>
								<?php if($phone!=''){?>
								<span class="phone"><i class="fa fa-phone" aria-hidden="true"></i> <a href="tel:<?php echo $phone;?>"><?php echo $phone;?></a></span>
								<?php } if($email!=''){?>
								<span class="email"><i class="fa fa-envelope" aria-hidden="true"></i> <a href="mailto:<?php echo $email;?>"><?php echo $email;?></a></span>
								<?php }?>
								<span class="top-social">                                     
								<?php if(get_field('social_icons', 'options')): ?>
									<ul class="social">Find us on 
									<?php while(has_sub_field('social_icons', 'options')): ?>
										<li><a href="<?php the_sub_field('link'); ?>" target="_blank">
											<i class="fa <?php the_sub_field('icon'); ?>"></i>
										</a></li>
									<?php endwhile; ?>
								</ul>
								<?php endif; ?> 
							</span>
							</div>
							</div>
						</div>
						<!-- <div class="col-md-4 navbar-center text-right">
							
						</div> -->
						<div class="col-md-6 navbar-right align-self-center">
							<div class="logg">
								<?php wp_nav_menu( array( 'theme_location' => 'top_menu' ) ); ?>
								<!-- <a href="/register/"><i class="fa fa-user"></i> Register </a> <?php /*if ( is_user_logged_in() ) {
										echo '<i class="fa fa-pencil-square-o"></i> <a href="'.get_edit_user_link().'">My Profile </a>';
										echo '<i class="fa fa-lock"></i> <a href="'.wp_logout_url().'">Logout </a>';
									}else{
										echo '<i class="fa fa-lock"></i> <a href="/log-in/">Login</a>';
									}*/?>  -->
							</div>
						</div>
					</div>
			</div>
		</div>
		<?php }?>
		<nav class="navbar navbar-expand-md navbar-trans fixed-top">

		<?php if ( 'container' == $container ) : ?>
			<div class="container-fluid">
		<?php endif; ?>
					<!-- Your site title as branding in the menu -->
					<?php if (  get_field('logo', 'options')!='' ) { ?>
						<a rel="home" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"><img src="<?php the_field('logo', 'options');?>" alt="logo" class="logo img-responsive"> <?php if (  get_field('text_header_logo', 'options')!='' ) {?><span class="text_logo"><?php the_field('text_header_logo', 'options');?></span><?php }?></a>
					<?php } else {?>
						<?php if ( is_front_page() && is_home() ) : ?>

							<h1 class="navbar-brand mb-0"><a rel="home" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"><?php bloginfo( 'name' ); ?></a></h1>
							
						<?php else : ?>

							<a class="navbar-brand" rel="home" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
						
						<?php endif; ?>
					<?php } ?><!-- end custom logo -->

				
					
				<div class="menu-right">
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation"><span class="icon-bar one"></span>
							<span class="icon-bar two"></span>
							<span class="icon-bar three"></span>
				</button>
				<!-- The WordPress Menu goes here -->
				 <?php wp_nav_menu(
					array(
						'theme_location'  => 'primary',
						'container_class' => 'collapse navbar-collapse',
						'container_id'    => 'navbarNavDropdown',
						'menu_class'      => 'navbar-nav',
						'fallback_cb'     => '',
						'menu_id'         => 'main-menu',
						'walker'          => new understrap_WP_Bootstrap_Navwalker(),
					)
				); ?> 
				</div>
			<?php if ( 'container' == $container ) : ?>
			</div><!-- .container -->
			<?php endif; ?>

		</nav><!-- .site-navigation -->

	</div><!-- .wrapper-navbar end -->
	<?php if ( !is_front_page() && !is_home() ) {
	$banner_image = get_field('banner_image');
	$banner_heading = get_field('banner_heading');
	$banner_sub_heading = get_field('banner_sub_heading');
 	$featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');
 	if($banner_image!=''){
 		$featured_img= $banner_image;
 	}elseif($featured_img_url!=''){ 
 		$featured_img= $featured_img_url;
 	}else{
 		$featured_img= get_field('default_header_image', 'options');
 	} ?>
	<section class="top-banner" style="background-image: url(<?php echo $featured_img;?>);">
		<header class="entry-header <?php if($banner_sub_heading!=''){ echo 'sub-heading-active';}?>">
			
			<?php //the_title( '<h1 class="entry-title">', '</h1>' ); ?>
			<h1 class="entry-title"><?php if($banner_heading!=''){echo $banner_heading;}else{wp_title('');} ?></h1>
			<?php if($banner_sub_heading!=''){ echo '<p class="sub-head">'.$banner_sub_heading.'</p>';}?>

			<?php if ( is_page_template( 'page-templates/page-blog.php' ) || is_singular('post') || is_category()) {?>
			<div class="tab_category shadow <?php if ( is_singular('post') ) {echo 'single '; 
			$category = get_the_category();
			$firstCategory = $category[0]->cat_name;}?>">
			<?php 	//echo $category_id = get_cat_ID('category');
					$terms = get_terms("category"); 
						$count = 1; 
							foreach ( $terms as $term ) { ?>
								<?php $icon = get_field('image', $term->taxonomy . '_' . $term->term_id);
									  $term_link = get_term_link( $term );
									  ?>
								<a href="<?php echo $term_link;?>" class ="term_links <?php if($count%3==1){echo 'blue';}elseif($count%3==2){echo 'green';}else{echo 'purple';} if($firstCategory==$term->name){echo ' active';}?>" id="term-link<?php echo $count;?>">
									<img src="<?php echo $icon?>" class="category-icon" alt="<?php echo $term->name;?>">
									<?php echo $term->name;?>
								</a>
								<?php $count++;
							} 
			?>
			</div>
			<?php }
			if ( is_page_template( 'page-templates/page-team.php' ) || is_page_template( 'page-templates/page-team-people.php' )){?>
				<div class="tab_category culture">
					<a href="<?php echo get_site_url(); ?>/team/" class="term_links team blue shadow">Culture</a>
					<a href="<?php echo get_site_url(); ?>/people/" class="term_links team purple shadow">People</a>
				</div>
			<?php }
			if ( is_singular( 'service' ) || is_post_type_archive('service') || is_tax( 'categories' )) {?>
				<div class="tab_category <?php if ( is_singular('service') ) {echo 'single-service '; 
			$category = wp_get_post_terms($post->ID, 'categories', array("fields" => "all"));
			$firstCategory = $category[0]->name;}?>">
			<?php 
					$terms = get_terms("categories"); 
						$count = 1; 
							foreach ( $terms as $term ) { ?>
								<?php $icon = get_field('image', $term->taxonomy . '_' . $term->term_id);
									  $term_link = get_term_link( $term );
									  ?>
								<a href="<?php echo $term_link;?>" class ="term_links shadow <?php if($count%3==1){echo 'blue';}elseif($count%3==2){echo 'green';}else{echo 'purple';} if($firstCategory==$term->name){echo ' active';}?>" id="term-link<?php echo $count;?>">
									<img src="<?php echo $icon?>" class="category-icon" alt="<?php echo $term->name;?>">
									<?php echo $term->name;?>
								</a>
								<?php $count++;
							} 
			?>
			</div>
		<?php	}?>
		</header>
	</section>
	<?php }?>
