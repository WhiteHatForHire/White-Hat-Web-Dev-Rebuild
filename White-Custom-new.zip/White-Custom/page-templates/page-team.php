<?php
/**
 * Template Name: Team Culture Page
 */

get_header();
$container = get_theme_mod( 'understrap_container_type' );
?>

<div class="wrapper" id="full-width-page-wrapper">

	<div class="<?php echo esc_attr( $container ); ?>" id="content">

		<div class="row">

			<div class="col-md-12 content-area" id="primary">

				<main class="site-main" id="main" role="main">

					<?php while ( have_posts() ) : the_post(); ?>

						<?php get_template_part( 'loop-templates/content', 'culture' ); ?>

						<?php
						// If comments are open or we have at least one comment, load up the comment template.
						if ( comments_open() || get_comments_number() ) :

							comments_template();

						endif;
						?>

					<?php endwhile; // end of the loop. ?>

				</main><!-- #main -->

			</div><!-- #primary -->

		</div><!-- .row end -->

	</div><!-- Container end -->

</div><!-- Wrapper end -->
<?php get_field('first_section_image');?>
<section class="culture-section first-sec">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-6 image-container-root">
				<img src="<?php the_field('first_section_image');?>" alt="bg-image" class="img-fluid bg-image-culture">
				<?php if(get_field('floating_image')!=''){?>
				<div class="image-container ">
					<img src="<?php the_field('floating_image');?>" alt="floting image" class="floating-image-culture shadow-low-opacity">
				</div>
				<?php }?>
			</div>
			<div class="col-md-6 text-container">
				<div class="imgae-container-text">
					<?php the_field('content');?>
				</div>
			</div>
		</div>
	</div>
</section>
<?php if( have_rows('parallax_elements') ): ?>
<section class="culture-section parallax-sec" data-stellar-background-ratio="0.5">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2 class="parallax-heading"></h2>
					<?php $count=1; while( have_rows('parallax_elements') ): the_row(); ?>
						<a href="javascript::" data-heading="<?php the_sub_field('parallax_heading'); ?>" data-image="<?php the_sub_field('parallax_image'); ?>" id="para-im<?php echo $count;?>" class="para-btn"><?php the_sub_field('button_name'); ?></a>
					<?php $count++; endwhile; ?>	
				</div>
			</div>
		</div>
</section>
<?php endif; ?>
<?php if( have_rows('job_opening') ): ?>
		<section class="job-opening text-center shadow" style="background-color: #00AAE9">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
					<ul class="job-statistics ">
					<?php $count=1; while( have_rows('job_opening') ): the_row(); ?>
					<li class="<?php if($count==1){echo 'large-vacancy';}?>">
						<span class="vacancy_total"><?php the_sub_field('vacancy_total'); ?></span>
						<span class="vacancy_name"><?php the_sub_field('vacancy_name'); ?></span>
					</li>
					<?php $count++; endwhile; ?>
					</ul>
					<div class="job-btn-container">
						<a href="<?php the_field('job_opening_link'); ?>" class="btn btn-primary white-btn">
							<?php the_field('job_opening_link_text'); ?>
						</a>
					</div>						
					</div>
				</div>
			</div>
		</section>
<?php endif; ?>
<?php if( have_rows('add_sections') ): ?>
	<?php $count=1; while( have_rows('add_sections') ): the_row(); $full_width = get_sub_field('full_width'); ?>
		<section class="team-sections" id="team-sections<?php echo $count;?>">
			<div class="container">
					<?php if($full_width!=''){ echo get_sub_field('content'); }else{ if($count%2==0){?>
					<div class="row">
					<div class="col-md-5">
						<div class="team-content left">
							<?php the_sub_field('section_content'); ?>
						</div>
					</div>
					<div class="col-md-7 team-content-image text-right">
						<img src="<?php the_sub_field('image'); ?>" class="img-fluid" alt="<?php the_title();?>">
					</div>
					</div>
					<?php }else{?>
					<div class="row">
					<div class="col-md-7 team-content-image text-left">
						<img src="<?php the_sub_field('image'); ?>" class="img-fluid" alt="<?php the_title();?>">
					</div>
					<div class="col-md-5">
						<div class="team-content right">
							<?php the_sub_field('section_content'); ?>
						</div>
					</div>
					</div>
					<?php }?>
					<?php }?>
			</div>
		</section>
	<?php $count++; endwhile; ?>
<?php endif; ?>
<?php get_footer(); ?>
<script>
	jQuery(document).ready(function(){
    var default_img = jQuery('#para-im1').attr('data-image');
    var default_heading = jQuery('#para-im1').attr('data-heading');
	jQuery('.culture-section.parallax-sec').css('background-image', 'url('+default_img+')');
	jQuery('.culture-section.parallax-sec .parallax-heading').text(default_heading);
	jQuery(".parallax-sec a").click(function(){
	  var default_img = jQuery(this).attr('data-image');
	  var default_heading = jQuery(this).attr('data-heading');
	  jQuery('.culture-section.parallax-sec').css('background-image', 'url('+default_img+')');
	  jQuery('.culture-section.parallax-sec .parallax-heading').text(default_heading);
	});
	});
	
</script>
