<?php
/**
 * Template Name: Section Page Template
 *
 *
 * @package WordPress
 */

get_header(); ?>
		
<?php
if( have_rows('sections') ):
$count=1;
    while ( have_rows('sections') ) : the_row();
?>
<div id="sections<?php echo $count ?>" class="sections entry-content <?php the_sub_field('custom_classes'); ?>" style="background-color:<?php the_sub_field('background_color') ?>;background-image:url(<?php the_sub_field('background_image') ?>);color:<?php the_sub_field('color') ?>;padding:<?php the_sub_field('padding') ?> 0px">
	<?php $val=get_sub_field('full_width'); ?>
	<div <?php  if($val[0] == "yes"){ ?> class="container-fluid" <?php }else{ ?> class="container" <?php } ?> >
		<?php the_sub_field('content') ?>
	</div>
</div>
<?php
$count++;
    endwhile;
endif;
?>
<?php get_footer(); 