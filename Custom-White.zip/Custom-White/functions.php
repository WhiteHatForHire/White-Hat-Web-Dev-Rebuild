<?php
/**
 * Understrap functions and definitions
 *
 * @package understrap
 */

/**
 * Initialize theme default settings
 */
require get_template_directory() . '/inc/theme-settings.php';

/**
 * Theme setup and custom theme supports.
 */
require get_template_directory() . '/inc/setup.php';

/**
 * Register widget area.
 */
require get_template_directory() . '/inc/widgets.php';

/**
 * Enqueue scripts and styles.
 */
require get_template_directory() . '/inc/enqueue.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/pagination.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Custom Comments file.
 */
require get_template_directory() . '/inc/custom-comments.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

/**
 * Load custom WordPress nav walker.
 */
require get_template_directory() . '/inc/bootstrap-wp-navwalker.php';

/**
 * Load WooCommerce functions.
 */
require get_template_directory() . '/inc/woocommerce.php';

/**
 * Load Editor functions.
 */
require get_template_directory() . '/inc/editor.php';

/**
 * Load ACF functions.
 */

require get_template_directory() . '/inc/acf_settings.php';

register_nav_menus( array(
	'top_menu' => 'Top Menu',
) );

function add_theme_scripts() {
  wp_enqueue_style( 'slider', get_template_directory_uri() . '/js/owl/owl.carousel.min.css', array(), '1.1', 'all');
  wp_enqueue_style( 'sliderstyle', get_template_directory_uri() . '/js/owl/owl.theme.default.min.css', array(), '1.1', 'all');
  wp_enqueue_script( 'script', get_template_directory_uri() . '/js/owl/owl.carousel.min.js', array (), 1.1, true);
}
add_action( 'wp_enqueue_scripts', 'add_theme_scripts' );


// create shortcode to list recent posts
add_shortcode( 'list-posts-basic', 'post_listing_shortcode' );
function post_listing_shortcode( $atts ) {
    ob_start();
    $query = new WP_Query( array(
        'post_type' => 'post',
        'posts_per_page' => -1,
        // 'order' => 'ASC',
        // 'orderby' => 'title',
    ) );
    if ( $query->have_posts() ) { ?>
        <div class="owl-carousel owl-theme post-listing">
            <?php while ( $query->have_posts() ) : $query->the_post(); $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); ?>
    			<div class="item">
    				<div class="card card-plain card-blog" id="post-<?php the_ID(); ?>" >
						<div class="card-image"> 
							<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"> 
							<img src="<?php echo esc_url($featured_img_url);?>" alt="<?php the_title(); ?>"> 
							</a>
						</div>
						<div class="content">
							<h6 class="date">
								<?php echo get_the_date(); ?>
							</h6>
							<h4 class="card-title"> 
								<a class="blog-item-title-link" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a>
							</h4>
							<p class="card-description"><?php the_excerpt(); ?></p>
						</div>
					</div>
    			</div>
            <?php endwhile;
            wp_reset_postdata(); ?>
        </div>
    <?php $myvariable = ob_get_clean();
    return $myvariable;
    }
}

add_shortcode( 'list-team-basic', 'team_listing_shortcode' );
function team_listing_shortcode( $atts ) {
    ob_start();
    $query = new WP_Query( array(
        'post_type' => 'team',
        'posts_per_page' => -1,
        // 'order' => 'ASC',
        // 'orderby' => 'title',
    ) );
    if ( $query->have_posts() ) { ?>
        <div class="row team_listing">
            <?php while ( $query->have_posts() ) : $query->the_post(); $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); ?>
    			<div class="col-sm-4">
    				<div class="card card-plain card-blog" id="post-<?php the_ID(); ?>" >
						<div class="card-image">
							<img src="<?php echo esc_url($featured_img_url);?>" alt="<?php the_title(); ?>">
						</div>
						<div class="content">
							<h4 class="card-title">
								<?php the_title(); ?>
							</h4>
							<div class="icons">
								<?php
								if( have_rows('social_icons') ):
								    while ( have_rows('social_icons') ) : the_row();
										echo '<a target="_blank" href="'.get_sub_field("link").'">';
								        the_sub_field('icon');
								        echo '</a>';
								    endwhile;
								endif;
								?>
							</div>
						</div>
					</div>
    			</div>
            <?php endwhile;
            wp_reset_postdata(); ?>
        </div>
    <?php $myvariable = ob_get_clean();
    return $myvariable;
    }
}

add_action('init', 'cptui_register_my_cpt_team');
function cptui_register_my_cpt_team() {
register_post_type('team', array(
'label' => 'Team',
'description' => '',
'public' => true,
'show_ui' => true,
'show_in_menu' => true,
'capability_type' => 'post',
'map_meta_cap' => true,
'hierarchical' => true,
'rewrite' => array('slug' => 'team', 'with_front' => true),
'query_var' => true,
'has_archive' => true,
'supports' => array('title','editor','thumbnail'),
'labels' => array (
  'name' => 'Team',
  'singular_name' => 'Team Member',
  'menu_name' => 'Team',
  'add_new' => 'Add Team Member',
  'add_new_item' => 'Add New Team Member',
  'edit' => 'Edit',
  'edit_item' => 'Edit Team Member',
  'new_item' => 'New Team Member',
  'view' => 'View Team Member',
  'view_item' => 'View Team Member',
  'search_items' => 'Search Team',
  'not_found' => 'No Team Found',
  'not_found_in_trash' => 'No Team Found in Trash',
  'parent' => 'Parent Team Member',
)
) ); }
add_post_type_support( 'team', 'page-attributes' );
//Vertical Bar
function bar_func( $atts ){
	return "<div class='separator'></div>";
}
add_shortcode( 'bar_use', 'bar_func' );