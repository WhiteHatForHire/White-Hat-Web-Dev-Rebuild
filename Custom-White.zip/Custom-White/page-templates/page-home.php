<?php
/**
 * Template Name: Home Page
 *
 * Template for displaying a Homepage without sidebar even if a sidebar widget is published.
 *
 * @package Adrishya
 */

get_header();
$container = get_theme_mod( 'understrap_container_type' );
?>
<div class="main_slider" style="background-image: url(<?php the_field('slider_background', 'options');?>)">
	<?php $slider = get_field('slider_code', 'options'); echo do_shortcode($slider);?>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="slider_content">
					<?php the_field('slider_content', 'options');?>
				</div>
			</div>
		</div>
				<div class="form_search">
					<form method="GET" action="http://adrishya.co/brgroup/jobs/">
					<div class="row">
					  <div class="col-lg-4 col-md-4 col-sm-6">
					  	<div class="search-input">
						    <label for="keywords">Keywords</label>
						    <input type="text" id="search_keywords" name="search_keywords" class="form-search"  placeholder="Search Keywords" />
						</div>
					  </div>
					  <div class="col-lg-3 col-md-3 col-sm-6">
					  	<div class="search-input">
					    <label for="keywords">Location</label>
					    <input type="text" id="search_location" name="search_location"  class="form-search" placeholder="Search Location" />
						</div>
					  </div>
					  <div class="col-lg-3 col-md-3 col-sm-6">
					  	<div class="search-input">
					  	<label for="search_category">Category</label>
					  	<select id="search_category" name="search_category"  class="form-search" >
					  		<?php foreach ( get_job_listing_categories() as $cat ) : ?>
					  			<option value="<?php echo esc_attr( $cat->term_id ); ?>"><?php echo esc_html( $cat->name ); ?></option>
					  		<?php endforeach; ?>
					  	</select>
					  </div>
					  </div>
					  <div class="col-lg-2 col-md-2 col-sm-12">
					  	<div class="search-btn">
					    	<input type="submit" value="Find Job"  class="btn btn-primary" />
						</div>
					  </div>
					</div>
					</form>
				</div>
		</div>
</div>

<div class="wrapper no_padding" id="full-width-page-wrapper">

	<div class="<?php echo esc_attr( $container ); ?>" id="content">

		<div class="row">

			<div class="col-md-12 content-area" id="primary">

				<main class="site-main" id="main" role="main">

					<?php while ( have_posts() ) : the_post(); ?>

						<?php get_template_part( 'loop-templates/content', 'home' ); ?>

					<?php endwhile; // end of the loop. ?>

				</main><!-- #main -->

			</div><!-- #primary -->

		</div><!-- .row end -->

	</div><!-- Container end -->
	<?php
		if( have_rows('sections', 'options') ): $i=0;
		    while ( have_rows('sections', 'options') ) : the_row(); $align = get_sub_field('image_allignment', 'options');?>
				<section class="home_sections" id="home_section<?php echo $i;?>">
					<div class="container">
						<div class="row">
							<div class="col-sm-6 <?php if($align=='Right'){echo 'push-sm-6 no_right_pad';}else{echo 'no_left_pad';}?>">
								<img src="<?php the_sub_field('image', 'options', 'options');?>" alt="sections" class="img-fluid">
							</div>
							<div class="col-sm-6 content_exc align-self-center <?php if($align=='Right'){echo 'pull-sm-6';}?>">
								<?php the_sub_field('content', 'options');?>
							</div>
					    </div>
					</div>
				</section>
		    <?php $i++; endwhile;
		endif;
		?>
		<?php
		if( have_rows('our_services', 'options') ): $i=1; $count = count(get_field('our_services', 'options'));
		if($count==3){$col=4;}elseif($count==4){$col=3;}else{$col=6;}?>
			<section class="our_services" style="background-image: url(<?php the_field('service_background', 'options');?>);">
					<div class="container">
						<div class="row">
							<div class="col-md-12 text-center"><h3><?php the_field('our_services_heading', 'options');?></h3></div>
		    				<?php while ( have_rows('our_services', 'options') ) : the_row();?>
							<div class="col-sm-<?php echo $col;?> text-center" id="our_services<?php echo $i;?>">
								<a href="<?php the_sub_field('link', 'options');?>">
									<div class="service_cta">
										<i class="fa <?php the_sub_field('icon', 'options');?>"></i>
										<h4><?php the_sub_field('heading', 'options');?></h4>
										<?php the_sub_field('content', 'options');?>
									</div>
								</a>
							</div>
		    				<?php $i++; endwhile;?>
		    			</div>
					</div>
			</section>
		<?php endif;
		?>
		<?php
		if( get_field('company_shortcode', 'options')!='' ): ?>
			<section class="latest_blogs latest_company">
					<div class="container">
						<div class="row">
							<div class="col-md-12 text-center">
								<h3><?php the_field('company_header', 'options');?></h3>
							</div>
							<div class="col-sm-12 text-center">
								<?php $company = get_field('company_shortcode', 'options');
									echo do_shortcode($company);
								?>
							</div>
		    			</div>
					</div>
			</section>
		<?php endif;
		?>
		<section class="latest_blogs latest_jobs">
					<div class="container">
						<div class="row">
							<div class="col-md-12 text-center" style="margin-bottom:15px;">
								<h3>Find a job you love</h3>
								<p>Each month, more than 5000+ jobseekers turn to website in their search for work</p>
							</div>
							<div class="col-sm-12 text-center">
								<?php echo do_shortcode('[latest-job-basic]');?>
							</div>
		    			</div>
					</div>
			</section>
		<?php
		if( get_field('latest_blog_shortcode', 'options')!='' ): ?>
			<section class="latest_blogs">
					<div class="container">
						<div class="row">
							<div class="col-md-12 text-center">
								<h3><?php the_field('latest_blogs_header', 'options');?></h3>
							</div>
							<div class="col-sm-12 text-center">
								<?php $blog = get_field('latest_blog_shortcode', 'options');
									echo do_shortcode($blog);
								?>
							</div>
		    			</div>
					</div>
			</section>
		<?php endif;
		?>
</div><!-- Wrapper end -->

<?php get_footer(); ?>
