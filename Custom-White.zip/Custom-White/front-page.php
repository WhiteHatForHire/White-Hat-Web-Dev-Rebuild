<?php
/**
 * Template Name: Front Page
 *
 * Template for displaying a Homepage without sidebar even if a sidebar widget is published.
 *
 * @package Adrishya
 */

get_header();
$container = get_theme_mod( 'understrap_container_type' );
?>
<?php
if( have_rows('sections', 'options') ):
$count=1;
    while ( have_rows('sections', 'options') ) : the_row();
?>
<div id="sections<?php echo $count ?>" class="sections entry-content <?php the_sub_field('custom_classes', 'options'); ?>" style="background-color:<?php the_sub_field('background_color', 'options') ?>;background-image:url(<?php the_sub_field('background_image', 'options') ?>);color:<?php the_sub_field('color', 'options') ?>;padding:<?php the_sub_field('padding', 'options') ?> 0px">
	<?php $val=get_sub_field('full_width', 'options'); ?>
	<div <?php  if($val != ""){ ?> class="container-fluid" <?php }else{ ?> class="container" <?php } ?> >
		<?php the_sub_field('content', 'options') ?>
	</div>
</div>
<?php
$count++;
    endwhile;
endif;
?>
<?php get_footer(); ?>