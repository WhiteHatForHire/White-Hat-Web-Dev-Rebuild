<?php
$container = get_theme_mod( 'understrap_container_type' );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-title" content="<?php bloginfo( 'name' ); ?> - <?php bloginfo( 'description' ); ?>">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php wp_head(); ?>
	<link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>">
	<?php if(get_field('smooth_scroll', 'options')!=''){?>
	<script src="<?php echo get_template_directory_uri().'/js/smooth/TweenMax.min.js'; ?>"></script>
	<script src="<?php echo get_template_directory_uri().'/js/smooth/ScrollToPlugin.min.js'; ?>"></script>
	<?php }?>
	<?php the_field('header_script', 'options');?>
</head>

<body <?php body_class(); ?>>

<div class="hfeed site" id="page">

	<!-- ******************* The Navbar Area ******************* -->
	<div class="wrapper-fluid wrapper-navbar" id="wrapper-navbar">

		<a class="skip-link screen-reader-text sr-only" href="#content"><?php esc_html_e( 'Skip to content',
		'understrap' ); ?></a>
		<?php if(get_field('header_top_bar', 'options')!=''){
			  $top_background_color = get_field('top_background_color', 'options');
			  $top_header_color = get_field('top_header_color', 'options'); ?>
		<div class="top-header" style="background-color: <?php echo $top_background_color;?>;color: <?php echo $top_header_color;?>">
		<div class="container">
			<div class="row">
						<div class="col-md-6 align-self-center">
							<div class="navbar-left">
								<div class="contact">
								<?php $phone=get_field('phone', 'options');
									  $email=get_field('email', 'options');
									   if($phone || $email!=''){echo 'Have any questions? ';}?>
								<?php if($phone!=''){?>
								<span class="phone"><i class="fa fa-phone" aria-hidden="true"></i> <a href="tel:<?php echo $phone;?>"><?php echo $phone;?></a></span>
								<?php } if($email!=''){?>
								<span class="email"><i class="fa fa-envelope" aria-hidden="true"></i> <a href="mailto:<?php echo $email;?>"><?php echo $email;?></a></span>
								<?php }?>
								<span class="top-social">                                     
								<?php if(get_field('social_icons', 'options')): ?>
									<ul class="social">Find us on 
									<?php while(has_sub_field('social_icons', 'options')): ?>
										<li><a href="<?php the_sub_field('link'); ?>" target="_blank">
											<i class="fa <?php the_sub_field('icon'); ?>"></i>
										</a></li>
									<?php endwhile; ?>
								</ul>
								<?php endif; ?> 
							</span>
							</div>
							</div>
						</div>
						<!-- <div class="col-md-4 navbar-center text-right">
							
						</div> -->
						<div class="col-md-6 navbar-right align-self-center">
							<div class="logg">
								<?php wp_nav_menu( array( 'theme_location' => 'top_menu' ) ); ?>
								<!-- <a href="/register/"><i class="fa fa-user"></i> Register </a> <?php /*if ( is_user_logged_in() ) {
										echo '<i class="fa fa-pencil-square-o"></i> <a href="'.get_edit_user_link().'">My Profile </a>';
										echo '<i class="fa fa-lock"></i> <a href="'.wp_logout_url().'">Logout </a>';
									}else{
										echo '<i class="fa fa-lock"></i> <a href="/log-in/">Login</a>';
									}*/?>  -->
							</div>
						</div>
					</div>
			</div>
		</div>
		<?php }?>
		<nav class="navbar navbar-expand-md navbar-dark">

		<?php if ( 'container' == $container ) : ?>
			<div class="container">
		<?php endif; ?>
					<!-- Your site title as branding in the menu -->
					<?php if (  get_field('logo', 'options')!='' ) { ?>
						<a rel="home" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"><img src="<?php the_field('logo', 'options');?>" alt="logo" class="logo img-responsive"> <?php if (  get_field('text_header_logo', 'options')!='' ) {?><span class="text_logo"><?php the_field('text_header_logo', 'options');?></span><?php }?></a>
					<?php } else {?>
						<?php if ( is_front_page() && is_home() ) : ?>

							<h1 class="navbar-brand mb-0"><a rel="home" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"><?php bloginfo( 'name' ); ?></a></h1>
							
						<?php else : ?>

							<a class="navbar-brand" rel="home" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
						
						<?php endif; ?>
					<?php } ?><!-- end custom logo -->

				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="menu-right">
				<!-- The WordPress Menu goes here -->
				<?php wp_nav_menu(
					array(
						'theme_location'  => 'primary',
						'container_class' => 'collapse navbar-collapse',
						'container_id'    => 'navbarNavDropdown',
						'menu_class'      => 'navbar-nav',
						'fallback_cb'     => '',
						'menu_id'         => 'main-menu',
						'walker'          => new understrap_WP_Bootstrap_Navwalker(),
					)
				); ?>
				</div>
			<?php if ( 'container' == $container ) : ?>
			</div><!-- .container -->
			<?php endif; ?>

		</nav><!-- .site-navigation -->

	</div><!-- .wrapper-navbar end -->
