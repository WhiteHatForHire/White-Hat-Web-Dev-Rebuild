<!-- <div class="newsletter"> -->
<?php //echo do_shortcode('[email-subscribers namefield="YES" desc="" group="Public"]');?>
<!-- </div> -->
<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package understrap
 */

$the_theme = wp_get_theme();
$container = get_theme_mod( 'understrap_container_type' );
?>

<?php get_sidebar( 'footerfull' ); ?>

<div class="wrapper" id="wrapper-footer">

	<div class="<?php echo esc_attr( $container ); ?>">

		<div class="row">

			<div class="col-md-12">

				<footer class="site-footer" id="colophon">

					<div class="site-info">
						<p class="text-center">Copyright © <?php echo date("Y");?> <?php echo $site_name = get_bloginfo( 'name' );  ?>. All Rights Reserved <span class="sep">|</span> Custom Web Design By <a href="https://adrishya.co/" target="_blank" title="Adrishya IT">Adrishya IT</a> </p>
					</div><!-- .site-info -->

				</footer><!-- #colophon -->

			</div><!--col end -->

		</div><!-- row end -->

	</div><!-- container end -->

</div><!-- wrapper end -->

</div><!-- #page we need this extra closing tag here -->

<?php wp_footer(); ?>
<?php the_field('footer_script', 'options');?>
<script>
	jQuery('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    dots:false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:3
        }
    }
})
	jQuery('ul.navbar-nav li.dropdown').hover(function() {
  jQuery(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
}, function() {
  jQuery(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
});
</script>
<?php if(get_field('smooth_scroll', 'options')!=''){?>
<script>
    var $ = jQuery;
    $(function(){
    
    var $window = $(window);        //Window object
    
    var scrollTime = 1.2;           //Scroll time
    var scrollDistance = 170;       //Distance. Use smaller value for shorter scroll and greater value for longer scroll
        
    $window.on("mousewheel DOMMouseScroll", function(event){
        
        event.preventDefault(); 
                                        
        var delta = event.originalEvent.wheelDelta/120 || -event.originalEvent.detail/3;
        var scrollTop = $window.scrollTop();
        var finalScroll = scrollTop - parseInt(delta*scrollDistance);
            
        TweenMax.to($window, scrollTime, {
            scrollTo : { y: finalScroll, autoKill:true },
                ease: Power1.easeOut,   //For more easing functions see https://api.greensock.com/js/com/greensock/easing/package-detail.html
                autoKill: true,
                overwrite: 5                            
            });
                    
    });
    
});
</script>
<?php }?>
</body>

</html>

