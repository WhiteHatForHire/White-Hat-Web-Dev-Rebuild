<?php
/**
 * Understrap functions and definitions
 *
 * @package understrap
 */

/**
 * Initialize theme default settings
 */
require get_template_directory() . '/inc/theme-settings.php';

/**
 * Theme setup and custom theme supports.
 */
require get_template_directory() . '/inc/setup.php';

/**
 * Register widget area.
 */
require get_template_directory() . '/inc/widgets.php';

/**
 * Enqueue scripts and styles.
 */
require get_template_directory() . '/inc/enqueue.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/pagination.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Custom Comments file.
 */
require get_template_directory() . '/inc/custom-comments.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

/**
 * Load custom WordPress nav walker.
 */
require get_template_directory() . '/inc/bootstrap-wp-navwalker.php';

/**
 * Load WooCommerce functions.
 */
require get_template_directory() . '/inc/woocommerce.php';

/**
 * Load Editor functions.
 */
require get_template_directory() . '/inc/editor.php';

/**
 * Load ACF functions.
 */

require get_template_directory() . '/inc/acf_settings.php';

register_nav_menus( array(
	'top_menu' => 'Top Menu',
  'footer_menu' => 'Footer Menu',
) );
function print_menu_shortcode($atts, $content = null) {
extract(shortcode_atts(array( 'name' => null, ), $atts));
return wp_nav_menu( array( 'menu' => $name, 'echo' => false ) );
}
add_shortcode('menu', 'print_menu_shortcode');
//[menu name="footer_menu"]

add_shortcode('menu', 'print_menu_shortcode');
function add_theme_scripts() {
  wp_enqueue_style( 'slider', get_template_directory_uri() . '/js/owl/owl.carousel.min.css', array(), '1.1', 'all');
  wp_enqueue_style( 'sliderstyle', get_template_directory_uri() . '/js/owl/owl.theme.default.min.css', array(), '1.1', 'all');
  wp_enqueue_script( 'script', get_template_directory_uri() . '/js/owl/owl.carousel.min.js', array (), 1.1, true);
}
add_action( 'wp_enqueue_scripts', 'add_theme_scripts' );


// create shortcode to list recent posts
add_shortcode( 'list-posts-basic', 'post_listing_shortcode' );
function post_listing_shortcode( $atts ) {
    ob_start();
    $query = new WP_Query( array(
        'post_type' => 'post',
        'posts_per_page' => -1,
        // 'order' => 'ASC',
        // 'orderby' => 'title',
    ) );
    if ( $query->have_posts() ) { $count=1; ?>
        <div class="owl-carousel owl-theme post-listing">
            <?php while ( $query->have_posts() ) : $query->the_post(); $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); ?>
    			<div class="item slide-list<?php echo $count; if($count%3==1){echo ' post-list1';}elseif($count%3==2){echo ' post-list2';}else{echo ' post-list3';}?> ">
            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"> 
    				<div class="card card-plain card-blog" id="post-<?php the_ID(); ?>" >
						<div class="card-image"> 
							<img src="<?php echo esc_url($featured_img_url);?>" alt="<?php the_title(); ?>">
						</div>
						<div class="content">
              <p class="category">
                <?php $categories = get_the_category();
                  if ( ! empty( $categories ) ) {
                      echo esc_html( $categories[0]->name );   
                }?> <span class="link-icon"><svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 80 80"><path d="M70.06,41.67a3.42,3.42,0,0,0,.17-.33,3.48,3.48,0,0,0,.11-.35c0-.1.07-.2.09-.3a3.52,3.52,0,0,0,0-1.37c0-.1-.06-.2-.09-.3a3.44,3.44,0,0,0-.11-.35,3.4,3.4,0,0,0-.17-.33c0-.09-.09-.18-.15-.27a3.53,3.53,0,0,0-.43-.53h0l-27-27a3.5,3.5,0,0,0-4.95,5l21,21H13a3.5,3.5,0,0,0,0,7H58.55l-21,21a3.5,3.5,0,1,0,4.95,5l27-27h0a3.53,3.53,0,0,0,.43-.53C70,41.85,70,41.76,70.06,41.67Z"></path></svg></span>
              </p>
              <h4 class="card-title"> 
                <?php the_title(); ?>
              </h4>
							<h6 class="date">
								<?php echo get_the_author_meta('display_name');?> - <?php echo get_the_date('j F, Y'); ?>
							</h6>
							<!-- <p class="card-description"><?php //the_excerpt(); ?></p> -->
						</div>
					</div>
          </a>
    			</div>
            <?php $count++; endwhile;
            wp_reset_postdata(); ?>
        </div>
    <?php $myvariable = ob_get_clean();
    return $myvariable;
    }
}

add_shortcode( 'list-team-basic', 'team_listing_shortcode' );
function team_listing_shortcode( $atts ) {
    ob_start();
    $query = new WP_Query( array(
        'post_type' => 'team',
        'posts_per_page' => -1,
        // 'order' => 'ASC',
        // 'orderby' => 'title',
    ) );
    if ( $query->have_posts() ) { ?>
        <div class="owl-carousel owl-theme team_listing">
            <?php while ( $query->have_posts() ) : $query->the_post(); $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); ?>
    			<div class="item">
    				<div class="card card-plain card-blog" id="post-<?php the_ID(); ?>" >
						<div class="card-image">
							<img src="<?php echo esc_url($featured_img_url);?>" alt="<?php the_title(); ?>">
						</div>
						<div class="content">
							<h4 class="card-title">
								<?php the_title(); ?>
							</h4>
							<p class="designation"><?php the_field('designation');?></p>
							<div class="icons">
								<?php
								if( have_rows('social_links') ):
								    while ( have_rows('social_links') ) : the_row();
										echo '<a target="_blank" href="'.get_sub_field("link").'">';
								        the_sub_field('icon');
								        echo '</a>';
								    endwhile;
								endif;
								?>
							</div>
						</div>
					</div>
    			</div>
            <?php endwhile;
            wp_reset_postdata(); ?>
        </div>
    <?php $myvariable = ob_get_clean();
    return $myvariable;
    }
}

add_action('init', 'cptui_register_my_cpt_testimonial');
function cptui_register_my_cpt_testimonial() {
register_post_type('testimonial', array(
'label' => 'Testimonial',
'description' => '',
'public' => true,
'show_ui' => true,
'show_in_menu' => true,
'capability_type' => 'post',
'map_meta_cap' => true,
'hierarchical' => true,
'rewrite' => array('slug' => 'testimonial', 'with_front' => true),
'query_var' => true,
'has_archive' => false,
'supports' => array('title','editor','thumbnail'),
'labels' => array (
  'name' => 'Testimonial',
  'singular_name' => 'Testimonial',
  'menu_name' => 'Testimonial',
  'add_new' => 'Add Testimonial',
  'add_new_item' => 'Add New Testimonial',
  'edit' => 'Edit',
  'edit_item' => 'Edit Testimonial',
  'new_item' => 'New Testimonial',
  'view' => 'View Testimonial',
  'view_item' => 'View Testimonial',
  'search_items' => 'Search Testimonial',
  'not_found' => 'NoTestimonial Found',
  'not_found_in_trash' => 'No Testimonial Found in Trash',
  
)
) ); }
add_post_type_support( 'testimonial', 'page-attributes' );
/*Client*/
add_action('init', 'cptui_register_my_cpt_client');
function cptui_register_my_cpt_client() {
register_post_type('client', array(
'label' => 'Clients',
'description' => '',
'public' => true,
'show_ui' => true,
'show_in_menu' => true,
'capability_type' => 'post',
'map_meta_cap' => true,
'hierarchical' => true,
'rewrite' => array('slug' => 'client', 'with_front' => true),
'query_var' => true,
'has_archive' => false,
'supports' => array('title','thumbnail'),
'labels' => array (
  'name' => 'Clients',
  'singular_name' => 'Client',
  'menu_name' => 'Clients',
  'add_new' => 'Add Client',
  'add_new_item' => 'Add New Client',
  'edit' => 'Edit',
  'edit_item' => 'Edit Client',
  'new_item' => 'New Client',
  'view' => 'View Client',
  'view_item' => 'View Client',
  'search_items' => 'Search Client',
  'not_found' => 'No Client Found',
  'not_found_in_trash' => 'No Client Found in Trash',
  
)
) ); }
add_post_type_support( 'client', 'page-attributes' );
/*Client Slider Shortcode*/
add_shortcode( 'list-client-basic', 'client_listing_shortcode' );
function client_listing_shortcode( $atts ) {
    ob_start();
    $query = new WP_Query( array(
        'post_type' => 'client',
        'posts_per_page' => -1,
        // 'order' => 'ASC',
        // 'orderby' => 'title',
    ) );
    if ( $query->have_posts() ) { ?>
        <div class="owl-carousel owl-theme client_listing">
            <?php while ( $query->have_posts() ) : $query->the_post(); $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); ?>
              <div class="item">
                <img src="<?php echo esc_url($featured_img_url);?>" alt="<?php the_title(); ?>">
              </div>
            <?php endwhile;
            wp_reset_postdata(); ?>
        </div>
    <?php $myvariable = ob_get_clean();
    return $myvariable;
    }
}

add_action('init', 'cptui_register_my_cpt_team');
function cptui_register_my_cpt_team() {
register_post_type('team', array(
'label' => 'Team',
'description' => '',
'public' => true,
'show_ui' => true,
'show_in_menu' => true,
'capability_type' => 'post',
'map_meta_cap' => true,
'hierarchical' => true,
'rewrite' => array('slug' => 'team', 'with_front' => true),
'query_var' => true,
'has_archive' => false,
'supports' => array('title','editor','thumbnail'),
'labels' => array (
  'name' => 'Team',
  'singular_name' => 'Team Member',
  'menu_name' => 'Team',
  'add_new' => 'Add Team Member',
  'add_new_item' => 'Add New Team Member',
  'edit' => 'Edit',
  'edit_item' => 'Edit Team Member',
  'new_item' => 'New Team Member',
  'view' => 'View Team Member',
  'view_item' => 'View Team Member',
  'search_items' => 'Search Team',
  'not_found' => 'No Team Found',
  'not_found_in_trash' => 'No Team Found in Trash',
  'parent' => 'Parent Team Member',
)
) ); }
add_post_type_support( 'team', 'page-attributes' );
add_action('init', 'cptui_register_team_taxes_categories');
function cptui_register_team_taxes_categories() {
register_taxonomy( 'team_options',array (
  0 => 'team',
),
array( 'hierarchical' => true,
  'label' => 'Team Options',
  'show_ui' => true,
  'query_var' => true,
  'show_admin_column' => false,
  'labels' => array (
    'search_items' => 'Team Options',
    'popular_items' => '',
    'all_items' => '',
    'parent_item' => '',
    'parent_item_colon' => '',
    'edit_item' => '',
    'update_item' => '',  
    'add_new_item' => '',
    'new_item_name' => '',
    'separate_items_with_commas' => '',
    'add_or_remove_items' => '',
    'choose_from_most_used' => '',
)
)); 
}

add_action('init', 'cptui_register_my_cpt_portfolio');
function cptui_register_my_cpt_portfolio() {
register_post_type('case', array(
'label' => 'Work',
'description' => '',
'public' => true,
'show_ui' => true,
'show_in_menu' => true,
'capability_type' => 'post',
'map_meta_cap' => true,
'hierarchical' => true,
'rewrite' => array('slug' => 'case', 'with_front' => true),
'query_var' => true,
'has_archive' => true,
'supports' => array('title','editor','thumbnail','excerpt'),
'labels' => array (
  'name' => 'Projects',
  'singular_name' => 'Work',
  'menu_name' => 'Works',
  'add_new' => 'Add Work',
  'add_new_item' => 'Add New Work',
  'edit' => 'Edit',
  'edit_item' => 'Edit Work',
  'new_item' => 'New Work',
  'view' => 'View Work',
  'view_item' => 'View Work',
  'search_items' => 'Search Work',
  'not_found' => 'No Works Found',
  'not_found_in_trash' => 'No Works Found in Trash',
  'parent' => 'Parent Work',
)
) ); 
}
add_post_type_support( 'case', 'page-attributes' );
add_action('init', 'cptui_register_my_taxes_categories');
function cptui_register_my_taxes_categories() {
register_taxonomy( 'categories',array (
  0 => 'case',
),
array( 'hierarchical' => true,
  'label' => 'Categories',
  'show_ui' => true,
  'query_var' => true,
  'show_admin_column' => false,
  'labels' => array (
    'search_items' => 'Category',
    'popular_items' => '',
    'all_items' => '',
    'parent_item' => '',
    'parent_item_colon' => '',
    'edit_item' => '',
    'update_item' => '',  
    'add_new_item' => '',
    'new_item_name' => '',
    'separate_items_with_commas' => '',
    'add_or_remove_items' => '',
    'choose_from_most_used' => '',
)
)); 
}

/*Service*/
add_action('init', 'cptui_register_my_cpt_service');
function cptui_register_my_cpt_service() {
register_post_type('service', array(
'label' => 'Service',
'description' => '',
'public' => true,
'show_ui' => true,
'show_in_menu' => true,
'capability_type' => 'post',
'map_meta_cap' => true,
'hierarchical' => true,
'rewrite' => array('slug' => 'service', 'with_front' => true),
'query_var' => true,
'has_archive' => true,
'supports' => array('title','editor','thumbnail','excerpt'),
'labels' => array (
  'name' => 'Service',
  'singular_name' => 'Service',
  'menu_name' => 'Service',
  'add_new' => 'Add Service',
  'add_new_item' => 'Add New Service',
  'edit' => 'Edit',
  'edit_item' => 'Edit Service',
  'new_item' => 'New Service',
  'view' => 'View Service',
  'view_item' => 'View Service',
  'search_items' => 'Search Service',
  'not_found' => 'No Services Found',
  'not_found_in_trash' => 'No Services Found in Trash',
  'parent' => 'Parent Service',
)
) ); 
}
add_post_type_support( 'service', 'page-attributes' );
add_action('init', 'cptui_register_service_taxes_categories');
function cptui_register_service_taxes_categories() {
register_taxonomy( 'categories',array (
  0 => 'service',
),
array( 'hierarchical' => true,
  'label' => 'Categories',
  'show_ui' => true,
  'query_var' => true,
  'show_admin_column' => false,
  'labels' => array (
    'search_items' => 'Category',
    'popular_items' => '',
    'all_items' => '',
    'parent_item' => '',
    'parent_item_colon' => '',
    'edit_item' => '',
    'update_item' => '',  
    'add_new_item' => '',
    'new_item_name' => '',
    'separate_items_with_commas' => '',
    'add_or_remove_items' => '',
    'choose_from_most_used' => '',
)
)); 
}

/*Job Team Page*/
add_action('init', 'cptui_register_my_cpt_job');
function cptui_register_my_cpt_job() {
register_post_type('job', array(
'label' => 'Job',
'description' => '',
'public' => true,
'show_ui' => true,
'show_in_menu' => true,
'capability_type' => 'post',
'map_meta_cap' => true,
'hierarchical' => true,
'rewrite' => array('slug' => 'job', 'with_front' => true),
'query_var' => true,
'has_archive' => false,
'supports' => array('title','editor','thumbnail','excerpt'),
'labels' => array (
  'name' => 'Job',
  'singular_name' => 'Job',
  'menu_name' => 'Jobs',
  'add_new' => 'Add Job',
  'add_new_item' => 'Add New Job',
  'edit' => 'Edit',
  'edit_item' => 'Edit Job',
  'new_item' => 'New Job',
  'view' => 'View Job',
  'view_item' => 'View Job',
  'search_items' => 'Search Job',
  'not_found' => 'No Job Found',
  'not_found_in_trash' => 'No Job Found in Trash',
  'parent' => 'Parent Job',
)
) ); 
}
/*Job Shortcode*/
add_shortcode( 'list-jobs-basic', 'jobs_listing_shortcode' );
function jobs_listing_shortcode( $atts ) {
    ob_start();
    $query = new WP_Query( array(
        'post_type' => 'job',
        'posts_per_page' => -1,
        // 'order' => 'ASC',
        // 'orderby' => 'title',
    ) );
    if ( $query->have_posts() ) { ?>
    <table class="table job-table table-responsive">
      <!-- <thead>
        <tr>
          <th scope="col">Job Name</th>
          <th scope="col">Type</th>
          <th scope="col">Location</th>
        </tr>
      </thead> -->
      <tbody>
            <?php $count=1; while ( $query->have_posts() ) : $query->the_post(); $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); $curl =get_field('apply_url'); ?>
            <tr>
              <!-- <th scope="row"><?php echo $count;?></th> -->
              <td><?php if($curl!=''){?><a href="<?php echo $curl;?>" target="_blank"><?php }else{?>
                <a href="<?php the_permalink();?>"> <?php }?>
                  <?php the_title(); ?>
                </a>
              </td>
              <td><?php the_field('job_type'); ?></td>
              <td><?php the_field('job_location'); ?></td>
              </tr>
            <?php $count++; endwhile;
            echo '</tbody></table>';
            wp_reset_postdata(); ?>
    <?php $myvariable = ob_get_clean();
    return $myvariable;
    }
}
/*Shortcode for display homepage work*/
add_shortcode( 'list-case-basic', 'case_listing_shortcode' );
function case_listing_shortcode( $atts ) {
    $atts = shortcode_atts(
    array(
      'type' => 'case',
      'category' => '',
      'per_page' => '2',
    ),
    $atts,
      'show_post'
    );
    ob_start();
    $query = new WP_Query( array(
        'post_type' => $atts['type'],
        'category_name' => $atts['category'],
        'posts_per_page' => $atts['per_page'],
    ) );
    if ( $query->have_posts() ) { 
        $count=1; ?>
            <?php while ( $query->have_posts() ) : $query->the_post(); 
            $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); ?>
            <div class="row">
              <div class="col-md-12">
              <div class="floating-sections <?php if($count%2==1){echo 'Left';}else{echo 'Right';}?>" id="post-<?php the_ID(); ?>">
              <a href="<?php the_permalink(); ?>">
              <?php if($featured_img_url!=''){?>
              <div class="section-image">
                <img src="<?php echo $featured_img_url; ?>" alt="home-sections" class="img-fluid">
              </div>
              <?php }?>
              <div class="section-content shadow">
                <h4><em><?php the_field('author_name');?></em></h4>
                <h3><?php the_title();?></h3>
                <h4><?php $content = get_the_content();
                          $trimmed_content = wp_trim_words( $content, 17, NULL );
                          echo $trimmed_content;?></h4>
                <?php the_sub_field('content', 'options') ?>
                <div class="section-content-button-container">
                  <span class="section-content-button">
                    <svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 80 80">
                      <path d="M40,11A29,29,0,0,0,11.08,38h33.1l-7.59-7.59a2,2,0,0,1,2.83-2.83l11,11a2,2,0,0,1,.25.31s.05.1.08.15a1.93,1.93,0,0,1,.1.19,2,2,0,0,1,.06.2c0,.06,0,.11.05.17a2,2,0,0,1,0,.78c0,.06,0,.11-.05.17a2,2,0,0,1-.06.2,1.93,1.93,0,0,1-.1.19c0,.05-.05.1-.08.15a2,2,0,0,1-.25.31l-11,11a2,2,0,0,1-2.83-2.83L44.17,42H11.08A29,29,0,1,0,40,11Z"></path>
                    </svg>
                  </span>
                </div>
              </div>
              </a>
              </div>
              </div>
            </div>
            <?php $count++; endwhile;
            wp_reset_postdata(); ?>
    <?php $myvariable = ob_get_clean();
    return $myvariable;
    }
}
//Shortcode to display 3 group images
add_shortcode( 'group_three_images', 'group_images_shortcode' );
function group_images_shortcode($atts) {
    ob_start(); ?>
        <?php if( have_rows('g_images') ): ?>
          <div class="image-three">
          <div class="row">
            <div class="col-md-6 left-image-three">
            <?php $count=1; while( have_rows('g_images') ): the_row(); ?>
            <?php if($count==3){ echo '</div><div class="col-md-6 right-image-three">';}?>
            <div class="group-image" id="main-three-img<?php echo $count;?>">
              <img src="<?php the_sub_field('m_image'); ?>" alt="<?php the_title();?>" class="img-fluid">
              <span class="group-text"><?php the_sub_field('image_text'); ?></span>
            </div>
            <?php $count++; endwhile; ?>
            </div>
          </div>
          </div>
        <?php
         endif; 
    $myvariable = ob_get_clean();
    return $myvariable;
}
//Shortcode to display Testimonials [custom-testimonials]
add_shortcode( 'custom-testimonials', 'custom_testimonials_shortcode' );
function custom_testimonials_shortcode($atts) {
    ob_start(); 
        $query = new WP_Query( array(
        'post_type' => 'testimonial',
        'posts_per_page' => -1,
        // 'order' => 'ASC',
        // 'orderby' => 'title',
    ) );
    if ( $query->have_posts() ) { ?>
    <!-- TESTIMONIALS -->
<section class="testimonials">
  <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div id="customers-testimonials" class="owl-carousel">
          <?php $count=1; while ( $query->have_posts() ) : $query->the_post(); $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); ?>
            <!--TESTIMONIAL <?php echo $count;?> -->
            <div class="item">
              <div class="shadow-effect">
                <img class="rounded-circle"" src="<?php echo $featured_img_url;?>" alt="<?php the_title();?>">
                <?php the_content();?>
              </div>
              <div class="testimonial-name"><?php the_title();?></div>
            </div>
            <!--END OF TESTIMONIAL <?php echo $count;?> -->
             <?php $count++; endwhile;
            wp_reset_postdata(); ?>
          </div>
        </div>
      </div>
      </div>
    </section>
    <!-- END OF TESTIMONIALS -->
    <?php }
    $myvariable = ob_get_clean();
    return $myvariable;
}

//Shortcode to display social icons [custom-socials]
add_shortcode( 'custom-socials', 'custom_socials_shortcode' );
function custom_socials_shortcode($atts) {
    ob_start(); ?>
    <?php if(get_field('social_icons', 'options')): ?>
		<ul class="social"><!-- Find us on  -->
		<?php while(has_sub_field('social_icons', 'options')): ?>
			<li><a href="<?php the_sub_field('link'); ?>" target="_blank">
				<i class="fa <?php the_sub_field('icon'); ?>"></i>
			</a></li>
		<?php endwhile; ?>
		</ul>
	<?php endif; ?> 
    <?php
    $myvariable = ob_get_clean();
    return $myvariable;
}
function heading_remove_tax_name( $title, $sep, $seplocation ) {
    if ( is_tax() ) {
        $term_title = single_term_title( '', false );
        if ( 'right' == $seplocation ) {
            $title = $term_title . " $sep ";
        } else {
            $title = " $sep " . $term_title;
        }
    }
    return $title;
}
add_filter( 'wp_title', 'heading_remove_tax_name', 10, 3 );
//Projects
add_action('init', 'cptui_register_my_cpt_projects');
function cptui_register_my_cpt_projects() {
register_post_type('projects', array(
'label' => 'Projects',
'description' => '',
'public' => true,
'show_ui' => true,
'show_in_menu' => true,
'capability_type' => 'post',
'map_meta_cap' => true,
'hierarchical' => true,
'rewrite' => array('slug' => 'projects', 'with_front' => true),
'query_var' => true,
'has_archive' => false,
'supports' => array('title','editor','thumbnail'),
'labels' => array (
  'name' => 'Project',
  'singular_name' => 'Project',
  'menu_name' => 'Projects',
  'add_new' => 'Add Project',
  'add_new_item' => 'Add New Project',
  'edit' => 'Edit',
  'edit_item' => 'Edit Projects',
  'new_item' => 'New Project',
  'view' => 'View Project',
  'view_item' => 'View Project',
  'search_items' => 'Search Project',
  'not_found' => 'No Project Found',
  'not_found_in_trash' => 'No Project Found in Trash',
  'parent' => 'Parent Project',
)
) ); }
add_post_type_support( 'projects', 'page-attributes' );
add_action('init', 'cptui_register_project_taxes_categories');
function cptui_register_project_taxes_categories() {
register_taxonomy( 'project_category',array (
  0 => 'projects',
),
array( 'hierarchical' => true,
  'label' => 'Project Category',
  'show_ui' => true,
  'query_var' => true,
  'show_admin_column' => false,
  'labels' => array (
    'search_items' => 'Project Category',
    'popular_items' => '',
    'all_items' => '',
    'parent_item' => '',
    'parent_item_colon' => '',
    'edit_item' => '',
    'update_item' => '',  
    'add_new_item' => '',
    'new_item_name' => '',
    'separate_items_with_commas' => '',
    'add_or_remove_items' => '',
    'choose_from_most_used' => '',
)
)); 
}
/*Shortcode for display Projects [list-project-basic per_page="8"]*/
add_shortcode( 'list-project-basic', 'project_listing_shortcode' );
function project_listing_shortcode( $atts ) {
    $atts = shortcode_atts(
    array(
      'type' => 'projects',
      'category' => '',
      'filter' => 'off',
      'per_page' => -1,
      'orderby' => 'date',
      'order'   => 'DESC',
    ),
    $atts,
      'show_post'
    );
    ob_start();
    $query = new WP_Query( array(
        'post_type' => $atts['type'],
        'category_name' => $atts['category'],
        'posts_per_page' => $atts['per_page'],
        'orderby' => $atts['orderby'],
        'order'   => $atts['order'],
    ) );
    if ( $query->have_posts() ) { 
        $count=1; ?>
        <?php if($atts['filter']=='on'){?>
          <div class="row">
            <div class="col-md-12 text-center filter-main">
            <a href="javascript::" data-filter="all" class="btn btn-outline-secondary filter-button active">All</a>
            <?php   $terms = get_terms("project_category"); 
                $count = 1; 
                  foreach ( $terms as $term ) { ?>
                      <a href="javascript::" data-filter="fill<?php echo $term->term_id;?>" class="btn btn-outline-secondary filter-button"><?php echo $term->name;?></a>
                  <?php $count++; }?>
            </div>
            </div>
        <?php }?>
        <div class="row project_custom" id="mix-wrapper">
            <?php while ( $query->have_posts() ) : $query->the_post();
            $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); ?>
              <div class="col-md-3 filter <?php $categories = get_the_terms( $post->ID, 'project_category' ); foreach( $categories as $category ) {echo 'fill'.$category->term_id.' ' ;} ?>">
              <div class="project-div" id="post-<?php the_ID(); ?>">
              <?php if($featured_img_url!=''){?>
                <img src="<?php echo $featured_img_url; ?>" alt="home-sections" class="img-fluid">
              <?php }?>
              <div class="project_url">
                  <a href="<?php echo $featured_img_url; ?>" class="image_popup" rel="prettyPhoto[project]">
                    <div class="project_wrap">
                        <div class="project_cont"><h4 class="item_title"><?php the_title();?></h4>
                            <div class="item_more">
                             <span class="zoom"></span>               
                           </div>   
                        </div>
                    </div>
                  </a>
              </div>
              </div>
              </div>
            <?php $count++; endwhile;
            echo '</div>';
            wp_reset_postdata(); ?>
    <?php $myvariable = ob_get_clean();
    return $myvariable;
    }
}
//Vertical Bar
function bar_func( $atts ){
	return "<div class='separator'></div>";
}
add_shortcode( 'bar_use', 'bar_func' );

