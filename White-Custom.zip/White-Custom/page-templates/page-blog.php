<?php
/**
 * Template Name: Blog Page Template
 *
 * Template for displaying all the blogs.
 *
 * @package understrap
 */

get_header();
$container = get_theme_mod( 'understrap_container_type' );
?>

<div class="wrapper" id="blog full-width-page-wrapper">

	<div class="<?php echo esc_attr( $container ); ?>" id="content">

		<div class="row">

			<div class="col-md-12 content-area" id="primary">

				<main class="site-main" id="main" role="main">

					<?php while ( have_posts() ) : the_post(); ?>

						<?php get_template_part( 'loop-templates/content', 'blog' ); ?>

						<?php
						// If comments are open or we have at least one comment, load up the comment template.
						if ( comments_open() || get_comments_number() ) :

							comments_template();

						endif;
						?>

					<?php endwhile; // end of the loop. ?>
				</main><!-- #main -->

			</div><!-- #primary -->
		</div><!-- .row end -->
			<div class="blog-all">
			<!--Blog Style-->
			<?php $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
			$args = array( 'post_type' => 'post', 'posts_per_page' => 10, 'paged' => $paged );
			$wp_query = new WP_Query($args);
			$count=1;
			while ( have_posts() ) : the_post(); 
			$featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); ?>
			<?php if($count%2==1){?>
				<div class="row left-blog">
					<div class="col-md-8">
						<a href="<?php the_permalink(); ?>">
							<img src="<?php echo $featured_img_url;?>" class="img-fluid blog-full-image" alt="<?php the_title() ?>"></a>
					</div>
					<div class="col-md-4">
						<h2><a href="<?php the_permalink(); ?>"><?php the_title() ?></a></h2>
						<?php the_excerpt();?>
					</div>
				</div>
			<?php }else{?>
				<div class="row right-blog">
					<div class="col-md-4">
						<h2><a href="<?php the_permalink(); ?>"><?php the_title() ?></a></h2>
						<?php the_excerpt();?>
					</div>
					<div class="col-md-8">
						<a href="<?php the_permalink(); ?>">
						<img src="<?php echo $featured_img_url;?>" class="img-fluid blog-full-image" alt="<?php the_title() ?>">
						</a>
					</div>
				</div>
			<?php } $count++; endwhile; ?>
			<!-- then the pagination links -->
			<?php next_posts_link( '&larr; Older posts', $wp_query ->max_num_pages); ?>
			<?php previous_posts_link( 'Newer posts &rarr;' ); ?>
			<!--Blog Style-->
			</div>
	</div><!-- Container end -->

</div><!-- Wrapper end -->

<?php get_footer(); ?>
