<?php
/**
 * Template Name: Team People Page
 */

get_header();
$container = get_theme_mod( 'understrap_container_type' );
?>

<div class="wrapper" id="full-width-page-wrapper">

	<div class="<?php echo esc_attr( $container ); ?>" id="content">

		<div class="row">

			<div class="col-md-12 content-area" id="primary">

				<main class="site-main" id="main" role="main">

					<?php while ( have_posts() ) : the_post(); ?>

						<?php get_template_part( 'loop-templates/content', 'page' ); ?>

						<?php
						// If comments are open or we have at least one comment, load up the comment template.
						if ( comments_open() || get_comments_number() ) :

							comments_template();

						endif;
						?>

					<?php endwhile; // end of the loop. ?>

				</main><!-- #main -->

			</div><!-- #primary -->

		</div><!-- .row end -->

	</div><!-- Container end -->

</div><!-- Wrapper end -->
<section class="people-page">
<div class="container-fluid">
	<div class="row">
		<div class="col-md-12 text-center filter-main">
		<a href="javascript::" data-filter="all" class="btn btn-outline-secondary filter-button active">All</a>
		<?php 	$terms = get_terms("team_options"); 
				$count = 1; 
					foreach ( $terms as $term ) { ?>
							<a href="javascript::" data-filter="fill<?php echo $term->term_id;?>" class="btn btn-outline-secondary filter-button"><?php echo $term->name;?></a>
					<?php $count++; }?>
		</div>
		</div>
		<?php $query = new WP_Query( array(
        'post_type' => 'team',
        'posts_per_page' => -1,
        // 'order' => 'ASC',
        // 'orderby' => 'title',
    ) );
    if ( $query->have_posts() ) { ?>
        <div class=" row teamm-listing-page">
            <?php $count=0; while ( $query->have_posts() ) : $query->the_post(); $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); ?>
    			<div class="col-md-3 filter <?php $categories = get_the_terms( $post->ID, 'team_options' ); foreach( $categories as $category ) {echo 'fill'.$category->term_id.' ' ;} ?>">
    				<div class="card card-plain card-blog" id="post-<?php the_ID(); ?>" >
						<a data-toggle="modal" href="#teamModal<?php echo $count;?>">
						<div class="card-image">
							<img src="<?php echo esc_url($featured_img_url);?>" alt="<?php the_title(); ?>">
						</div>
						</a>
						<div class="content">
							<h4 class="card-title">
								<?php the_title(); ?>
							</h4>
							<p class="designation"><?php the_field('designation');?></p>
							<div class="icons">
								<?php
								if( have_rows('social_links') ):
								    while ( have_rows('social_links') ) : the_row();
										echo '<a target="_blank" href="'.get_sub_field("link").'">';
								        the_sub_field('icon');
								        echo '</a>';
								    endwhile;
								endif;
								?>
							</div>
						</div>
					</div>
    			</div>
    			<div class="modal" id="teamModal<?php echo $count;?>">
				  <div class="modal-dialog modal-lg">
				    <div class="modal-content">

				      <!-- Modal Header -->
				      <div class="modal-header">
				        <h4 class="modal-title"><?php the_title(); ?> - <small><?php the_field('designation');?></small></h4>
				        <button type="button" class="close" data-dismiss="modal">&times;</button>
				      </div>

				      <!-- Modal body -->
				      <div class="modal-body">
				        <?php the_content();?>
				      </div>

				      <!-- Modal footer -->
				      <div class="modal-footer">
				        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
				      </div>

				    </div>
				  </div>
				</div>
            <?php $count++; endwhile;
            wp_reset_postdata(); ?>
        </div>
        <?php }?>
</div>
</section>
<?php get_footer(); ?>
