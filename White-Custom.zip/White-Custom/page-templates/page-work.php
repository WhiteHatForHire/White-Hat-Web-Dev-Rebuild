<?php
/**
 * Template Name: Work Page
 */

get_header();
$container = get_theme_mod( 'understrap_container_type' );
?>

<div class="wrapper" id="full-width-page-wrapper">

	<div class="<?php echo esc_attr( $container ); ?>" id="content">

		<div class="row">

			<div class="col-md-12 content-area" id="primary">

				<main class="site-main" id="main" role="main">

					<?php while ( have_posts() ) : the_post(); ?>

						<?php get_template_part( 'loop-templates/content', 'page' ); ?>

						<?php
						// If comments are open or we have at least one comment, load up the comment template.
						if ( comments_open() || get_comments_number() ) :

							comments_template();

						endif;
						?>

					<?php endwhile; // end of the loop. ?>

				</main><!-- #main -->

			</div><!-- #primary -->

		</div><!-- .row end -->

	</div><!-- Container end -->
<div class="container">
<div class="row">
			<?php
			$args = array(
				'post_type' => 'case',
				'posts_per_page' => -1,
				'orderby' => 'menu_order',
                 'order' => 'ASC'
			);
			$query = new WP_Query( $args );
			?>
			<?php
			while ($query->have_posts() ): $query->the_post(); 
			$image = wp_get_attachment_url( get_post_thumbnail_id($post->ID)); ?>
			<div class="col-md-6">
			
			<div class="post-div">
			<a href="<?php the_permalink(); ?>">
			<div class="featured-img" style="background-image: url(<?php echo $image; ?>);">
			</div>
			<div class="post-content">
			<div class="case-extract-small-bg">
			<div class="case-extract-small-bg-inner" style="background-color: <?php the_field('bg_overlay_color'); ?>">
			</div>
			</div>
			<div class="case-extract-small-text">
			<span><?php the_field('author_name'); ?></span>
			<h3><?php the_title(); ?></h3>
			<h4><?php the_field('banner_sub_heading'); ?></h4>
			<div class="hover-arrow text-right"><img src="/wp-content/uploads/2018/12/arrow-cirlce.png" alt="Forward"></div>
			</div>
			</div>
			</a>
			</div>
			
			</div>
			<?php endwhile; // end of the loop. ?>
</div>
</div>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<?php the_field('page_below_content', '130'); ?>
		</div>
	</div>
</div>
</div><!-- Wrapper end -->

<?php get_footer(); ?>
