<?php
/**
 * Template Name: Front Page
 *
 * Template for displaying a Homepage without sidebar even if a sidebar widget is published.
 *
 * @package Adrishya
 */

get_header();
$container = get_theme_mod( 'understrap_container_type' );
?>
<div class="slider">
	<?php echo do_shortcode(get_field('slider_shortcode', 'options'));?>
</div>

<?php
if( have_rows('homepage_cta', 'options') ):
$count=1;
echo '<div class="homepage_cta" id="services"><div class="container" ><div class="row"><div class="col-md-12">';
echo '<h2 class="heading">'.get_field('homepage_cta_heading', 'options').'</h2></div></div><div class="row">';
    while ( have_rows('homepage_cta', 'options') ) : the_row();
    $image= get_sub_field('image', 'options');
?>
	<div class="col-md-4 ctas <?php the_sub_field('extra_class', 'options') ?>">
		<div class="home-cta">
		<?php if($image!=''){?><img src="<?php echo $image;?>" alt="home-sections" class="img-fluid"><?php }else{ if($count==1){?>
			<div class="services-item-small-shape shadow">
				<div class="shape">
					<svg class="shape-trail-diamond svg-shape" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 399 400">
						<g filter="" fill="none" fill-rule="evenodd" transform="translate(50 20)">
						<rect class="shape-trail-diamond-bg" width="299.848" height="299.973" fill="#FE595B" rx="4"></rect>
						<rect class="shape-trail-diamond-front" width="144.23" height="144.29" x="77.607" y="79.804" fill="#00AAE9" rx="4" transform="rotate(45 149.722 151.95)"></rect>
						</g>
					</svg>
				</div>
			</div>
			<?php }elseif($count==2){?>
			<div class="services-item-small-shape shadow">
				<div class="shape">
					<svg class="shape-trail-double-diamond svg-shape" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 399 399">
						<g filter="" fill="none" fill-rule="evenodd" transform="translate(50 20)">
						<rect class="shape-trail-double-diamond-bg" width="299.511" height="299.824" fill="#45D33C" rx="4"></rect>
						<g transform="translate(33 71)">
						<rect class="shape-trail-double-diamond-back" width="109.818" height="110.183" x="23.053" y="23.337" fill="#FFE044" rx="4" transform="rotate(45 77.961 78.429)"></rect>
						<rect class="shape-trail-double-diamond-front" width="109.818" height="110.183" x="100.772" y="23.271" fill="#FE595B" rx="4" transform="rotate(45 155.68 78.362)"></rect>
						</g>
						</g>
					</svg>
				</div>
			</div>
			<?php }else{ ?>
			<div class="services-item-small-shape shadow">
				<div class="shape">
					<svg class="shape-trail-triangle svg-shape" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 399 399">
					<g fill="none" fill-rule="evenodd">
					<rect class="shape-trail-triangle-bg" filter="" width="299.511" height="299.824" fill="#FFE044" rx="4" transform="translate(50 20)"></rect>
					<path class="shape-trail-triangle-front" fill="#8415BC" d="M304.768 249.844l-213.275-.18a1.494 1.494 0 0 1-1.276-2.27L198.31 75.718a1.494 1.494 0 0 1 2.552-.004L309.78 247.57c.43.704.21 1.623-.494 2.054-.236.144-4.242.22-4.518.22z"></path>
					</g>
					</svg>
				</div>
			</div>
			<?php }?>
		<?php }?>
			<div class="cta_content">
			<?php the_sub_field('content', 'options'); 
			 if(get_sub_field('cta_button', 'options')): 
			  	while(has_sub_field('cta_button', 'options')): ?>
					<a href="<?php the_sub_field('button_link'); ?>" class="btn btn-success">
						<?php the_sub_field('button_text'); ?> 
						<!--<span class="icon"><span class="icon_main"><svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 80 80"><path d="M70.06,41.67a3.42,3.42,0,0,0,.17-.33,3.48,3.48,0,0,0,.11-.35c0-.1.07-.2.09-.3a3.52,3.52,0,0,0,0-1.37c0-.1-.06-.2-.09-.3a3.44,3.44,0,0,0-.11-.35,3.4,3.4,0,0,0-.17-.33c0-.09-.09-.18-.15-.27a3.53,3.53,0,0,0-.43-.53h0l-27-27a3.5,3.5,0,0,0-4.95,5l21,21H13a3.5,3.5,0,0,0,0,7H58.55l-21,21a3.5,3.5,0,1,0,4.95,5l27-27h0a3.53,3.53,0,0,0,.43-.53C70,41.85,70,41.76,70.06,41.67Z"></path></svg></span></span> -->
					</a>
				<?php endwhile; 
			endif; ?> 
			</div>
		</div>
	</div>
<?php
$count++;
    endwhile;
    echo '</div></div></div>';
endif;
?>

<?php
echo '<div class="home_sections"><div class="container" >';
echo '<div class="row"><div class="col-md-12 section_heading">'.get_field('home_sections_heading', 'options').'</div></div>';
echo do_shortcode(get_field('home_sections', 'options'));
echo '</div></div>';
?>

<?php
if( have_rows('sections', 'options') ):
$count=1;
    while ( have_rows('sections', 'options') ) : the_row();
?>
<div id="home_sections<?php echo $count ?>" class="sections entry-content <?php the_sub_field('custom_classes', 'options'); if(get_sub_field('parallax', 'options')!=''){echo ' parallax';}?>" style="background-color:<?php the_sub_field('background_color', 'options') ?>;background-image:url(<?php the_sub_field('background_image', 'options') ?>);color:<?php the_sub_field('color', 'options') ?>;padding:<?php the_sub_field('padding', 'options') ?> 0px">
	<?php $val=get_sub_field('full_width', 'options'); ?>
	<div <?php  if($val != ""){ ?> class="container-fluid" <?php }else{ ?> class="container" <?php } ?> >
		<?php the_sub_field('content', 'options') ?>
	</div>
</div>
<?php
$count++;
    endwhile;
endif;
?>
<?php get_footer(); ?>